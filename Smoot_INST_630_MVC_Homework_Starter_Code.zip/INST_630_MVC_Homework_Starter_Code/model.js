const restaurantModel = {
  restaurants: [
    { name: "Milano's", cuisine: "Italian", rating: 4.5, price: '$$' },
    { name: "Sakura Sushi", cuisine: "Japanese", rating: 4.2, price: '$$$'},
    { name: "The Brass Elephant", cuisine: "American", rating: 4.8, price: '$$$'},
    { name: "Pho Corner", cuisine: "Vietnamese", rating: 4.3, price: '$'},
    { name: "Tandoor Palace", cuisine: "Indian", rating: 4.1, price: '$'}
  ],

  getAllRestaurants: function () {
    return this.restaurants;
  },
  getInexpensiveRestaurants: function () {
    return this.restaurants.filter(function (restaurant) {
      return restaurant.price == '$';
    });
  },
  getRestaurantsByCuisine: function (cuisine) {
    return this.restaurants.filter(function (restaurant) {
      return restaurant.cuisine === cuisine;
    });
},

  getTopRatedRestaurants: function () {
    return this.restaurants.filter(function (restaurant) {
      return restaurant.rating >= 4.5;
    });
  }
};
