const restaurantController = {
  init: function () {
    const showAllButton = document.querySelector("#showAll");
    const showTopRatedButton = document.querySelector("#showTopRated");
    const showInexpensiveButton = document.querySelector("#showInexpensive");
    const select = document.querySelector("#showCuisine");

    showAllButton.addEventListener("click", function () {
      const restaurants = restaurantModel.getAllRestaurants();
      restaurantView.displayRestaurants(restaurants);
    });

    showTopRatedButton.addEventListener("click", function () {
      const restaurants = restaurantModel.getTopRatedRestaurants();
      restaurantView.displayRestaurants(restaurants);
    });
    showInexpensiveButton.addEventListener("click", function() {
      const restaurants = restaurantModel.getInexpensiveRestaurants();
      restaurantView.displayRestaurants(restaurants);
    });
    select.addEventListener("change", function () {
      const cuisine = select.value;
      const filteredRestaurants = restaurantModel.getRestaurantsByCuisine(cuisine);
      restaurantView.displayRestaurants(filteredRestaurants);
    });

    restaurantView.displayRestaurants(restaurantModel.getAllRestaurants());
  }
};

restaurantController.init();
